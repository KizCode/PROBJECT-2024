package id.ac.telkomuniversity.praktikumpbo.model;

public enum StatusPesanan {
    MASUK_ANTRIAN,
    DIMASAK,
    SELESAI_DIMASAK,
    SUDAH_DIHIDANGKAN,
    SUDAH_DIKEMAS,
    DIBATALKAN
}
