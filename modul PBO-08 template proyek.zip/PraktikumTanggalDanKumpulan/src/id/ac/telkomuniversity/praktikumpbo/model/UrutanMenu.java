package id.ac.telkomuniversity.praktikumpbo.model;

public enum UrutanMenu {
    ACAK,
    BERDASARKAN_NAMA,
    BERDASARKAN_KATEGORI
}
