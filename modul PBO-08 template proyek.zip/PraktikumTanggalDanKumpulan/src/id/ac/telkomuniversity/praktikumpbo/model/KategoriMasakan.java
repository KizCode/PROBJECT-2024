package id.ac.telkomuniversity.praktikumpbo.model;

public enum KategoriMasakan {
    PEMBUKA,
    HIDANGAN_UTAMA,
    MINUMAN,
    MAKANAN_RINGAN
}
